import { Link, useLocation } from 'react-router-dom'
import { cn } from '@/lib/utils'
import {
  BarChart3,
  Shield,
  TrendingUp,
  Building2,
  Bell
} from 'lucide-react'

const navigation = [
  { name: 'Overview', href: '/', icon: BarChart3 },
  { name: 'Risk & Controls', href: '/risk-controls', icon: Shield },
  { name: 'Orders & Positions', href: '/orders-positions', icon: TrendingUp },
  { name: 'Venues', href: '/venues', icon: Building2 },
  { name: 'Alerts', href: '/alerts', icon: Bell },
]

export function Sidebar() {
  const location = useLocation()

  return (
    <div className="fixed left-0 top-0 z-40 h-screen bg-card border-r border-border transition-all duration-300 w-64">
      <div className="flex h-full flex-col">
        <div className="flex h-16 items-center border-b border-border px-6">
          <h1 className="text-lg font-semibold">AutoTrader Hub</h1>
        </div>
        <nav className="flex-1 space-y-1 p-4">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href
            return (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.name}
              </Link>
            )
          })}
        </nav>
        <div className="border-t border-border p-4">
          <div className="text-xs text-muted-foreground">
            Last updated • {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  )
}
