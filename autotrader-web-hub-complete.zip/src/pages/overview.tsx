import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, getTimeAgo } from '@/lib/utils'
import { api } from '@/lib/api'
import { useToast } from '@/hooks/use-toast'
import { 
  Pause, 
  Play, 
  ExternalLink, 
  Activity,
  DollarSign,
  TrendingUp,
  TrendingDown
} from 'lucide-react'

export function Overview() {
  const [isLoading, setIsLoading] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [killSwitchActive, setKillSwitchActive] = useState(false)
  const { toast } = useToast()

  const handlePause = async () => {
    setIsLoading(true)
    const result = await api.pause()
    if (result.error) {
      toast({
        title: "Error",
        description: result.error,
        variant: "destructive"
      })
    } else {
      setKillSwitchActive(true)
      toast({
        title: "Trading Paused",
        description: "All trading activities have been paused"
      })
    }
    setIsLoading(false)
  }

  const handleResume = async () => {
    setIsLoading(true)
    const result = await api.resume()
    if (result.error) {
      toast({
        title: "Error",
        description: result.error,
        variant: "destructive"
      })
    } else {
      setKillSwitchActive(false)
      toast({
        title: "Trading Resumed",
        description: "Trading activities have been resumed"
      })
    }
    setIsLoading(false)
  }

  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(new Date())
    }, 30000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="ml-64 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">AutoTrader Web Hub</h1>
          <p className="text-muted-foreground">3-Sleeve Autonomous Trading System</p>
          <p className="text-sm text-muted-foreground mt-1">
            Last updated • {getTimeAgo(lastUpdated.toISOString())}
          </p>
        </div>
        {killSwitchActive && (
          <Badge variant="destructive" className="text-sm">
            KILL SWITCH ACTIVE
          </Badge>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Equity</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(10000)}</div>
            <p className="text-xs text-green-600">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +0.00% (24h)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">PnL Today</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">+{formatCurrency(0)}</div>
            <p className="text-xs text-muted-foreground">
              0 trades executed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">7d PnL</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(0)}</div>
            <p className="text-xs text-muted-foreground">
              No change from last week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Drawdown</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0.00%</div>
            <p className="text-xs text-muted-foreground">
              Within acceptable limits
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span>🟢 Trading Bot</span>
              <Badge variant="success">Active</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>🟢 API Server</span>
              <Badge variant="success">Online</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>📄 Mode</span>
              <Badge variant="secondary">Paper Trading</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Trading Sleeves</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span>⚡ Arbitrage</span>
              <Badge variant={killSwitchActive ? "destructive" : "success"}>
                {killSwitchActive ? "Paused" : "Active"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>📊 Swing</span>
              <Badge variant="secondary">Inactive</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>🎯 Event</span>
              <Badge variant="secondary">Inactive</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {killSwitchActive ? (
              <Button 
                onClick={handleResume} 
                disabled={isLoading}
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="mr-2 h-4 w-4" />
                Resume All Trading
              </Button>
            ) : (
              <Button 
                onClick={handlePause} 
                disabled={isLoading}
                variant="destructive"
              >
                <Pause className="mr-2 h-4 w-4" />
                Pause All Trading
              </Button>
            )}
            
            <Button variant="outline" asChild>
              <a href="/ops/grafana/" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-2 h-4 w-4" />
                View Grafana
              </a>
            </Button>
            
            <Button variant="outline" asChild>
              <a href="/api/health" target="_blank" rel="noopener noreferrer">
                <Activity className="mr-2 h-4 w-4" />
                API Health
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
