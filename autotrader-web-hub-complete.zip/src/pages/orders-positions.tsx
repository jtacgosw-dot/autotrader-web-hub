import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatLatency } from '@/lib/utils'
import { api, Order, Position } from '@/lib/api'
import { useToast } from '@/hooks/use-toast'
import { Download, Filter } from 'lucide-react'

export function OrdersPositions() {
  const [orders, setOrders] = useState<Order[]>([])
  const [positions, setPositions] = useState<Position[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      const [ordersResult, positionsResult] = await Promise.all([
        api.getOrders(200),
        api.getPositions()
      ])

      if (ordersResult.data) {
        setOrders(ordersResult.data)
      } else if (ordersResult.error) {
        toast({
          title: "Error fetching orders",
          description: ordersResult.error,
          variant: "destructive"
        })
        setOrders([
          {
            time_iso: new Date().toISOString(),
            pair: 'ETH/USDT',
            side: 'BUY',
            size: 1.20,
            entry_price: 1987.50,
            current_price: 1992.30,
            fees_usd: 2.38,
            slippage_bps: 3.2,
            latency_ms: 287,
            venue: 'Binance',
            pnl_realized_usd: 5.76,
            order_id: 'o_9q3g5',
            trade_id: 't_44b1a'
          }
        ])
      }

      if (positionsResult.data) {
        setPositions(positionsResult.data)
      } else if (positionsResult.error) {
        toast({
          title: "Error fetching positions",
          description: positionsResult.error,
          variant: "destructive"
        })
        setPositions([
          {
            pair: 'BTC/USDT',
            size: 0.05,
            entry_price: 43250.00,
            current_price: 43180.00,
            pnl_unrealized: -3.50,
            venue: 'Binance'
          }
        ])
      }

      setLoading(false)
    }

    fetchData()
    const interval = setInterval(fetchData, 30000)
    return () => clearInterval(interval)
  }, [toast])

  const exportCSV = () => {
    const headers = [
      'time_iso', 'pair', 'side', 'size', 'entry_price', 'current_price',
      'fees_usd', 'slippage_bps', 'latency_ms', 'venue', 'pnl_realized_usd',
      'order_id', 'trade_id'
    ]
    
    const csvContent = [
      headers.join(','),
      ...orders.map(order => [
        order.time_iso,
        order.pair,
        order.side,
        order.size,
        order.entry_price,
        order.current_price,
        order.fees_usd,
        order.slippage_bps,
        order.latency_ms,
        order.venue,
        order.pnl_realized_usd,
        order.order_id,
        order.trade_id
      ].join(','))
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `orders_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)

    toast({
      title: "Export Complete",
      description: "Orders exported to CSV file"
    })
  }

  const exportJSONL = () => {
    const jsonlContent = orders.map(order => JSON.stringify({
      ts: order.time_iso,
      pair: order.pair,
      side: order.side,
      qty: order.size,
      price: order.entry_price,
      notional_usd: order.size * order.entry_price,
      fee_usd: order.fees_usd,
      slippage_bps: order.slippage_bps,
      latency_ms: order.latency_ms,
      venue: order.venue,
      pnl_realized_usd: order.pnl_realized_usd,
      order_id: order.order_id,
      trade_id: order.trade_id
    })).join('\n')

    const blob = new Blob([jsonlContent], { type: 'application/jsonl' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `orders_${new Date().toISOString().split('T')[0]}.jsonl`
    a.click()
    URL.revokeObjectURL(url)

    toast({
      title: "Export Complete",
      description: "Orders exported to JSONL file"
    })
  }

  if (loading) {
    return (
      <div className="ml-64 p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading orders and positions...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="ml-64 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Orders & Positions</h1>
          <p className="text-muted-foreground">Trading activity and current positions</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <Button onClick={exportCSV} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            CSV
          </Button>
          <Button onClick={exportJSONL} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            JSONL
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Time</th>
                    <th className="text-left p-2">Pair</th>
                    <th className="text-left p-2">Side</th>
                    <th className="text-right p-2">Size</th>
                    <th className="text-right p-2">Price</th>
                    <th className="text-right p-2">Fees</th>
                    <th className="text-right p-2">Slippage</th>
                    <th className="text-right p-2">Latency</th>
                    <th className="text-left p-2">Venue</th>
                    <th className="text-right p-2">PnL</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.order_id} className="border-b">
                      <td className="p-2 text-xs">
                        {new Date(order.time_iso).toLocaleTimeString()}
                      </td>
                      <td className="p-2 font-medium">{order.pair}</td>
                      <td className="p-2">
                        <Badge variant={order.side === 'BUY' ? 'success' : 'destructive'}>
                          {order.side}
                        </Badge>
                      </td>
                      <td className="p-2 text-right">{order.size.toFixed(4)}</td>
                      <td className="p-2 text-right">{formatCurrency(order.entry_price)}</td>
                      <td className="p-2 text-right">{formatCurrency(order.fees_usd)}</td>
                      <td className="p-2 text-right">{order.slippage_bps.toFixed(1)} bps</td>
                      <td className="p-2 text-right">{formatLatency(order.latency_ms)}</td>
                      <td className="p-2">{order.venue}</td>
                      <td className={`p-2 text-right font-medium ${
                        order.pnl_realized_usd >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {formatCurrency(order.pnl_realized_usd)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Open Positions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {positions.map((position, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{position.pair}</span>
                  <Badge variant="outline">{position.venue}</Badge>
                </div>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Size:</span>
                    <span>{position.size.toFixed(4)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Entry:</span>
                    <span>{formatCurrency(position.entry_price)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Current:</span>
                    <span>{formatCurrency(position.current_price)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Unrealized PnL:</span>
                    <span className={position.pnl_unrealized >= 0 ? 'text-green-600' : 'text-red-600'}>
                      {formatCurrency(position.pnl_unrealized)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
            {positions.length === 0 && (
              <div className="text-center text-muted-foreground py-8">
                No open positions
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
