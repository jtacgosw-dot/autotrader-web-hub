import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert } from '@/lib/api'
import { getTimeAgo } from '@/lib/utils'
import { AlertTriangle, AlertCircle, Info, Bell } from 'lucide-react'

export function Alerts() {
  const [alerts] = useState<Alert[]>([
    {
      id: '1',
      severity: 'CRITICAL',
      message: 'Binance connection lost - attempting reconnection',
      timestamp: new Date(Date.now() - 300000).toISOString(),
      venue: 'Binance',
      resolved: false
    },
    {
      id: '2',
      severity: 'WARN',
      message: 'KuCoin latency above threshold (p95: 850ms)',
      timestamp: new Date(Date.now() - 600000).toISOString(),
      venue: 'KuCoin',
      resolved: true
    },
    {
      id: '3',
      severity: 'INFO',
      message: 'Trading resumed after manual pause',
      timestamp: new Date(Date.now() - 900000).toISOString(),
      resolved: false
    }
  ])

  const getSeverityIcon = (severity: Alert['severity']) => {
    switch (severity) {
      case 'CRITICAL':
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      case 'WARN':
        return <AlertCircle className="h-4 w-4 text-yellow-600" />
      case 'INFO':
        return <Info className="h-4 w-4 text-blue-600" />
    }
  }

  const getSeverityVariant = (severity: Alert['severity']) => {
    switch (severity) {
      case 'CRITICAL':
        return 'destructive' as const
      case 'WARN':
        return 'warning' as const
      case 'INFO':
        return 'secondary' as const
    }
  }

  const groupedAlerts = alerts.reduce((acc, alert) => {
    if (!acc[alert.severity]) {
      acc[alert.severity] = []
    }
    acc[alert.severity].push(alert)
    return acc
  }, {} as Record<Alert['severity'], Alert[]>)

  return (
    <div className="ml-64 p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Alerts</h1>
        <p className="text-muted-foreground">System alerts and notifications digest</p>
      </div>

      <div className="grid gap-6">
        {(['CRITICAL', 'WARN', 'INFO'] as const).map((severity) => {
          const severityAlerts = groupedAlerts[severity] || []
          if (severityAlerts.length === 0) return null

          return (
            <Card key={severity}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {getSeverityIcon(severity)}
                  {severity} Alerts ({severityAlerts.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {severityAlerts.map((alert) => (
                    <div
                      key={alert.id}
                      className="flex items-start justify-between p-4 border rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={getSeverityVariant(alert.severity)}>
                            {alert.severity}
                          </Badge>
                          {alert.venue && (
                            <Badge variant="outline">{alert.venue}</Badge>
                          )}
                          {alert.resolved && (
                            <Badge variant="success">Resolved</Badge>
                          )}
                        </div>
                        <p className="text-sm">{alert.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {getTimeAgo(alert.timestamp)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {alerts.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No alerts</h3>
            <p className="text-muted-foreground">
              All systems are operating normally
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
