import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatLatency } from '@/lib/utils'
import { api, VenueHealth } from '@/lib/api'
import { useToast } from '@/hooks/use-toast'
import { Building2, Activity, AlertTriangle } from 'lucide-react'

export function VenuesLatency() {
  const [venues, setVenues] = useState<VenueHealth[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchVenues = async () => {
      const result = await api.getVenuesHealth()
      if (result.data) {
        setVenues(result.data)
      } else if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive"
        })
        setVenues([
          {
            venue: 'Binance',
            p50: 45,
            p95: 120,
            p99: 280,
            rejects: 0.2,
            reconnects: 0,
            errors: 2,
            enabled: true
          },
          {
            venue: 'KuCoin',
            p50: 65,
            p95: 180,
            p99: 420,
            rejects: 0.8,
            reconnects: 1,
            errors: 5,
            enabled: true
          }
        ])
      }
      setLoading(false)
    }

    fetchVenues()
    const interval = setInterval(fetchVenues, 30000)
    return () => clearInterval(interval)
  }, [toast])

  const getLatencyColor = (p95: number) => {
    if (p95 < 100) return 'text-green-600'
    if (p95 < 300) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getRejectColor = (rejects: number) => {
    if (rejects < 1) return 'text-green-600'
    if (rejects < 5) return 'text-yellow-600'
    return 'text-red-600'
  }

  if (loading) {
    return (
      <div className="ml-64 p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading venue data...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="ml-64 p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Venues & Latency</h1>
        <p className="text-muted-foreground">Trading venue performance and connectivity</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {venues.map((venue) => (
          <Card key={venue.venue}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  {venue.venue}
                </CardTitle>
                <Badge variant={venue.enabled ? "success" : "destructive"}>
                  {venue.enabled ? "Enabled" : "Disabled"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">p50</div>
                  <div className="text-lg font-semibold">{formatLatency(venue.p50)}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">p95</div>
                  <div className={`text-lg font-semibold ${getLatencyColor(venue.p95)}`}>
                    {formatLatency(venue.p95)}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">p99</div>
                  <div className="text-lg font-semibold">{formatLatency(venue.p99)}</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">Rejects</div>
                  <div className={`text-lg font-semibold ${getRejectColor(venue.rejects)}`}>
                    {venue.rejects.toFixed(1)}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">Reconnects</div>
                  <div className="text-lg font-semibold">{venue.reconnects}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">Errors</div>
                  <div className="text-lg font-semibold">{venue.errors}</div>
                </div>
              </div>

              {(venue.p95 > 800 || venue.rejects > 5) && (
                <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <span className="text-sm text-red-800">
                    Circuit breaker triggered - auto-disabled
                  </span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button 
                  variant={venue.enabled ? "destructive" : "default"}
                  size="sm"
                  className="flex-1"
                >
                  {venue.enabled ? "Disable" : "Enable"}
                </Button>
                <Button variant="outline" size="sm">
                  <Activity className="h-4 w-4 mr-2" />
                  View Errors
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>24h Latency Heatmap</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            Latency heatmap visualization would be implemented here
            <br />
            (venue vs hour grid showing p95 latency trends)
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
