import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { api, RiskLimits } from '@/lib/api'
import { useToast } from '@/hooks/use-toast'
import { getTimeAgo } from '@/lib/utils'
import { Shield, AlertTriangle, Pause, Play } from 'lucide-react'

export function RiskControls() {
  const [limits, setLimits] = useState<RiskLimits>({
    per_trade_cap: 1.0,
    daily_drawdown_kill: 1.0,
    max_slippage_bps: 5,
    last_changed_by: 'system',
    last_changed_at: new Date().toISOString()
  })
  const [newLimits, setNewLimits] = useState(limits)
  const [killSwitchActive, setKillSwitchActive] = useState(false)
  const [confirmAction, setConfirmAction] = useState<'PAUSE' | 'RESUME' | null>(null)
  const [confirmText, setConfirmText] = useState('')
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchLimits = async () => {
      const result = await api.getRiskLimits()
      if (result.data) {
        setLimits(result.data)
        setNewLimits(result.data)
      } else if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive"
        })
      }
      setLoading(false)
    }

    fetchLimits()
  }, [toast])

  const handleUpdateLimits = async () => {
    const result = await api.updateRiskLimits(newLimits)
    if (result.error) {
      toast({
        title: "Error",
        description: result.error,
        variant: "destructive"
      })
    } else {
      setLimits(newLimits)
      toast({
        title: "Risk Limits Updated",
        description: "New risk parameters have been applied"
      })
    }
  }

  const handleConfirmAction = async () => {
    if (confirmAction === 'PAUSE' && confirmText === 'PAUSE') {
      const result = await api.pause()
      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive"
        })
      } else {
        setKillSwitchActive(true)
        toast({
          title: "Trading Paused",
          description: "All trading activities have been paused"
        })
      }
    } else if (confirmAction === 'RESUME' && confirmText === 'RESUME') {
      const result = await api.resume()
      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive"
        })
      } else {
        setKillSwitchActive(false)
        toast({
          title: "Trading Resumed",
          description: "Trading activities have been resumed"
        })
      }
    }
    setConfirmAction(null)
    setConfirmText('')
  }

  if (loading) {
    return (
      <div className="ml-64 p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading risk controls...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="ml-64 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Risk & Controls</h1>
          <p className="text-muted-foreground">Trading risk management and safety controls</p>
        </div>
        {killSwitchActive && (
          <Badge variant="destructive" className="text-sm">
            <AlertTriangle className="h-4 w-4 mr-2" />
            KILL SWITCH ACTIVE
          </Badge>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Emergency Controls
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!confirmAction ? (
              <div className="flex gap-4">
                {killSwitchActive ? (
                  <Button 
                    onClick={() => setConfirmAction('RESUME')}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Resume Trading
                  </Button>
                ) : (
                  <Button 
                    onClick={() => setConfirmAction('PAUSE')}
                    variant="destructive"
                    className="flex-1"
                  >
                    <Pause className="mr-2 h-4 w-4" />
                    Pause Trading
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    Type <strong>{confirmAction}</strong> to confirm this action:
                  </p>
                </div>
                <input
                  type="text"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  placeholder={`Type ${confirmAction} here`}
                />
                <div className="flex gap-2">
                  <Button 
                    onClick={handleConfirmAction}
                    disabled={confirmText !== confirmAction}
                    variant={confirmAction === 'PAUSE' ? 'destructive' : 'default'}
                    className={confirmAction === 'RESUME' ? 'bg-green-600 hover:bg-green-700' : ''}
                  >
                    Confirm {confirmAction}
                  </Button>
                  <Button 
                    onClick={() => {
                      setConfirmAction(null)
                      setConfirmText('')
                    }}
                    variant="outline"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Risk Parameters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="text-sm font-medium">Per-trade cap: {(newLimits.per_trade_cap * 100).toFixed(1)}%</label>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={newLimits.per_trade_cap}
                onChange={(e) => setNewLimits({...newLimits, per_trade_cap: parseFloat(e.target.value)})}
                className="w-full mt-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>0.5%</span>
                <span>2.0%</span>
              </div>
              {newLimits.per_trade_cap !== limits.per_trade_cap && (
                <div className="text-xs text-blue-600 mt-1">
                  {(limits.per_trade_cap * 100).toFixed(1)}% → {(newLimits.per_trade_cap * 100).toFixed(1)}%
                </div>
              )}
            </div>

            <div>
              <label className="text-sm font-medium">Daily drawdown kill: {(newLimits.daily_drawdown_kill * 100).toFixed(1)}%</label>
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.1"
                value={newLimits.daily_drawdown_kill}
                onChange={(e) => setNewLimits({...newLimits, daily_drawdown_kill: parseFloat(e.target.value)})}
                className="w-full mt-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>0.5%</span>
                <span>1.5%</span>
              </div>
              {newLimits.daily_drawdown_kill !== limits.daily_drawdown_kill && (
                <div className="text-xs text-blue-600 mt-1">
                  {(limits.daily_drawdown_kill * 100).toFixed(1)}% → {(newLimits.daily_drawdown_kill * 100).toFixed(1)}%
                </div>
              )}
            </div>

            <div>
              <label className="text-sm font-medium">Max slippage: {newLimits.max_slippage_bps} bps</label>
              <input
                type="range"
                min="2"
                max="8"
                step="1"
                value={newLimits.max_slippage_bps}
                onChange={(e) => setNewLimits({...newLimits, max_slippage_bps: parseInt(e.target.value)})}
                className="w-full mt-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>2 bps</span>
                <span>8 bps</span>
              </div>
              {newLimits.max_slippage_bps !== limits.max_slippage_bps && (
                <div className="text-xs text-blue-600 mt-1">
                  {limits.max_slippage_bps} bps → {newLimits.max_slippage_bps} bps
                </div>
              )}
            </div>

            <Button 
              onClick={handleUpdateLimits}
              disabled={JSON.stringify(newLimits) === JSON.stringify(limits)}
              className="w-full"
            >
              Update Risk Limits
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-50 p-4 rounded-lg">
            <pre className="text-xs text-gray-700">
{JSON.stringify({
  per_trade_cap: limits.per_trade_cap,
  daily_drawdown_kill: limits.daily_drawdown_kill,
  max_slippage_bps: limits.max_slippage_bps,
  kill_switch_active: killSwitchActive
}, null, 2)}
            </pre>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Last changed by {limits.last_changed_by} • {getTimeAgo(limits.last_changed_at)}
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
