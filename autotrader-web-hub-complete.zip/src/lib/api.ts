const API_BASE_URL = (import.meta as any).env.VITE_API_BASE_URL || 'https://lunaraxolotl.com'

export interface ApiResponse<T> {
  data?: T
  error?: string
}

export interface HealthStatus {
  status: string
  service: string
}

export interface VenueHealth {
  venue: string
  p50: number
  p95: number
  p99: number
  rejects: number
  reconnects: number
  errors: number
  enabled: boolean
}

export interface Order {
  time_iso: string
  pair: string
  side: 'BUY' | 'SELL'
  size: number
  entry_price: number
  current_price: number
  fees_usd: number
  slippage_bps: number
  latency_ms: number
  venue: string
  pnl_realized_usd: number
  order_id: string
  trade_id: string
}

export interface Position {
  pair: string
  size: number
  entry_price: number
  current_price: number
  pnl_unrealized: number
  venue: string
}

export interface RiskLimits {
  per_trade_cap: number
  daily_drawdown_kill: number
  max_slippage_bps: number
  last_changed_by: string
  last_changed_at: string
}

export interface Alert {
  id: string
  severity: 'CRITICAL' | 'WARN' | 'INFO'
  message: string
  timestamp: string
  venue?: string
  resolved: boolean
}

async function apiCall<T>(endpoint: string, options?: RequestInit): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    const data = await response.json()
    return { data }
  } catch (error) {
    return { error: error instanceof Error ? error.message : 'Unknown error' }
  }
}

export const api = {
  health: () => apiCall<HealthStatus>('/api/health'),
  pause: () => apiCall('/api/pause', { method: 'POST' }),
  resume: () => apiCall('/api/resume', { method: 'POST' }),
  resetKillSwitch: () => apiCall('/api/reset-kill-switch', { method: 'POST' }),
  getRiskLimits: () => apiCall<RiskLimits>('/api/risk'),
  updateRiskLimits: (limits: Partial<RiskLimits>) => 
    apiCall('/api/risk', {
      method: 'POST',
      body: JSON.stringify(limits),
    }),
  getVenuesHealth: () => apiCall<VenueHealth[]>('/api/venues/health'),
  getOrders: (limit = 200, since?: string) => {
    const params = new URLSearchParams({ limit: limit.toString() })
    if (since) params.append('since', since)
    return apiCall<Order[]>(`/api/orders?${params}`)
  },
  getPositions: () => apiCall<Position[]>('/api/positions'),
}
