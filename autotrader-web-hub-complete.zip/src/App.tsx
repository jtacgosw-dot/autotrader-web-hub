import { Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Sidebar } from '@/components/sidebar'
import { Overview } from '@/pages/overview'
import { VenuesLatency } from '@/pages/venues-latency'
import { OrdersPositions } from '@/pages/orders-positions'
import { RiskControls } from '@/pages/risk-controls'
import { Alerts } from '@/pages/alerts'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-background font-sans antialiased">
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 overflow-auto transition-all duration-300">
          <Routes>
            <Route path="/" element={<Overview />} />
            <Route path="/venues" element={<VenuesLatency />} />
            <Route path="/orders-positions" element={<OrdersPositions />} />
            <Route path="/risk-controls" element={<RiskControls />} />
            <Route path="/alerts" element={<Alerts />} />
          </Routes>
        </main>
      </div>
      <Toaster />
    </div>
  )
}

export default App
